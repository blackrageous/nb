void netsnmp_access_systemstats_arch_init(void);
int netsnmp_access_systemstats_container_arch_load(netsnmp_container* container,
                                                   u_int load_flags);
