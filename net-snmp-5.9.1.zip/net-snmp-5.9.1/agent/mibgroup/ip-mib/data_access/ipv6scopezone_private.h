int netsnmp_access_scopezone_container_arch_load(netsnmp_container* container,
                                                 u_int load_flags);
