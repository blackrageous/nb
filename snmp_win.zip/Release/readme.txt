snmpWalk.exe 192.168.0.100 1.3.6.1.2.1.1.0.0 -v3 -t1000 -sntest3 -sl3 -sm3 -authSHA224 -privAES256 -uaNetbrain1! -upNetbrain1!
snmpWalk.exe 172.24.32.225 1.3.6.1.2.1.1.0.0 -v1 -Cnb

if you want get detail log,  rename libsnmp++_withlog.dll to libsnmp++_.dll